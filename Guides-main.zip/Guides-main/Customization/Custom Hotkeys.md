# Setting Custom Hotkeys
<sup><sup>(Author: Zeteo)</sup></sup>

Customizing your hotkeys is fairly simple, but a little more complex than clicking a button in a hotkey menu and reassigning it

## How Do

1. While in game, (preferrably vs an inactive ai), go into your settings > Control > Keybinds and select the hotkey preset you wish to edit
2. While still in keybinds, select custom (this will create a text file based on the previous preset chosen)
3. 

From here you can change the text input to whatever you want
