


Basics should be as short/simple as possible to get people in the door

Basics should simply cover the building blocks / fundementals of playing well








