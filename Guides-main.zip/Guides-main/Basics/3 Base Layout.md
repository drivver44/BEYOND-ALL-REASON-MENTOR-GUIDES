
Some buildings chain explode

Know how much damage and how big the radius with shift + space and x + space

Do not put buildings that chain too close together

Converters, Geos, Fusions and storages explode extra

Self-D explosions are generally larger and can sometimes deal extra damage / have EMP effect
