# Playing Faster

## Train your APM

### Practice Important Key Strokes

### Box Selection

### The Importance of Mind and body
- The important thing is to get your mind/body actively prepared for what you need to do before the game even starts
	- This means getting used to doing box selections and keystrokes so you can do these things more quickly
	- As you practice this, your mind may begin to wander - try to bring your focus back until it becomes second nature
   	- When it does become second nature, you can then allow your mind to wander, but warming up your hands to do the motions can still be helpful
