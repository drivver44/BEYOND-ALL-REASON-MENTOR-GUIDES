Basic Guide to Making Guides




## Notes:

We want 1 general nav page that links to the overview pages?

**Non-Technical guides should be simple to follow and not overly detailed**

For now, the guides are just being made, they are overly detailed at the moment and could probably be more concise
Parts of some guides could probably be moved to other areas or in a guide of their own

Some guides here may be redundant with what's on the website - I wanted to write some of those anyways to have a fresh view to sort of double check if anything is missing from there. These redundant guides need not be used

## Formatting: 

Don't really have a clear format yet
