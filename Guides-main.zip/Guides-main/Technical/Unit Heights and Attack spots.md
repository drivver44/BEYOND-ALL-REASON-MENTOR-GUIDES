
Units have different attack at points and fire from points

alt + v to see information
