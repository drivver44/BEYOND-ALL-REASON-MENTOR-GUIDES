


Technical guides are for those looking to dive deeper - All math related stuff should basically be broken down here and the more technical inner workings of the game









