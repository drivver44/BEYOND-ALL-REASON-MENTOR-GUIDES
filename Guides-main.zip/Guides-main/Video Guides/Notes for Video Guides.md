

### Misc Videos
---------------------------------------------------------------------------

Brand New (how to find resources and online guides)


<br>

### Starting Guides
---------------------------------------------------------------------------
Bot fundementals

Vehicle fundementals

ship fundementals

air fundementals


Differences between arm and core

- Bots
- Vehicle
- Air
- Sea
- Hovercraft
- Amphibious



<br>

### Basic Guides
---------------------------------------------------------------------------

****T1 Economy Fundementals**<br>
- *When you are out of a resource, prioritize that resource
- Secure metal by controlling space
- When to use Converters
- When to build Adv Solar / Geo

****T2 Economy Fundementals**<br>
- Fusions / T2 converters
- When T2 converters become more efficient

****Importance of Controlling Space with commander and troops**

**Importance of Reclaim**
- When to reclaim / when to ressurect


**Basic Raiding**<br>
- When to raid, when to hold off

**Getting Basic Information**<br>
- Scouting
- What to look for


<br>

### Intermediate
---------------------------------------------------------------------------
Lab Transitions

T2 Transitions (When it's appropriate/how to / buying a con)

Playing Dedicated Air


Communication is OP

Importance of Sharing Resources





<br>

### Advanced
---------------------------------------------------------------------------

Gathering Information<br>
- Scouting later in the match
- Making Informed Decisions

Giving out T2 constructors (when it's appropriate)

Late Game Strategies (What to do in different circumstances/having impact)




<br>

### Customization
---------------------------------------------------------------------------
How to Install Widgets

How to Setup Custom Hotkeys

How to import Custom Music

Settings Overview


<br>

### Technical
---------------------------------------------------------------------------
Different energy openers

Calculating Build Time and M/E per sec


Math on when to Wind

Math on when to Tide

Math on Energy Production efficiency<br>
- When to build a type of E producer

Math on When T2 converters are better than T1





NOTE:: Some of this stuff I have the math for in spreadsheets (it needs revision for readability)

		https://docs.google.com/spreadsheets/d/1HZ0Ablfd_vz9fbkIVlxJU2mcOeOWLBLtqBtagjbFcKs/edit#gid=940959777


<br>

### Tools for Training
---------------------------------------------------------------------------
Practicing Map Awareness

Increasing APM / playing faster

How to Test Stuff

Watch Good Players



