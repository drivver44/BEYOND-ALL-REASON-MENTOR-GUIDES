
NOTES:
-----------------


- This ended up being a giant list of guides I think should end getting made eventually.
- It's hard to say which ones are top priority, as usually people have some reasonable 
  game sense before they even know about reviews.
- The list may seem rather long, but BAR is rather complex and there is a lot of details to go over.
- I'm not 100% sure on the exact breakdown, especially when considering trying to keep the videos as short as possible

- I think the stuff under 'Basic' is probably the highest priority
	- I find even some of the reviews of people above 30 sometimes have trouble with
	  some of the fundemental 'basic stuff' and need a reminder to properly
	  spend/make a req resource.
	- Also, these basic guides could probably be broken down into several parts as
	  they are multifaceted / quite important



- Also see the rest of the github repository I've created, it's something I've been working on for a little bit now
	- It's a bit overly detailed IMO
	- This has been a way for me to create an outline for guides
	- Some of the stuff I wrote is already on the website
	- The list here was made independently from the other stuff in this repository, so there may be some differences


- Ultimately, I think the website guides could be cleaned up
	- Some guides are nested / hidden within other guides
	- In some cases there is some redundant information
	- Overall, these guides should be compiled into 1 navigable tab where people can see all the different topics


