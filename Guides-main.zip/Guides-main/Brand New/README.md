This is currently formatted for discord
