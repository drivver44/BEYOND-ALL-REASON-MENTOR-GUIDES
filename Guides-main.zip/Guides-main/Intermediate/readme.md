



Intermediate is outlined for players who have mastered the basics and are looking for information going over slightly more advanced topics without going too deep









