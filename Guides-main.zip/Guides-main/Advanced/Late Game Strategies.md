
# Late Game Strategies
<sub></sup>(Author: Zeteo)</sup></sub>

### BAR has a lot of skill expression and there are oftentimes many ways to skin a cat
### Figuring out what's going to work best in a given situation relies on getting information to make informed decisions


## Some of the Possible Super Later Game Strategies

Going T3
Heavy Duty T2
T1 spam
Hovercraft spam
Amphibious Play
Bombers
Abductors


## Some of the Possible Early-Late Game Strategies
