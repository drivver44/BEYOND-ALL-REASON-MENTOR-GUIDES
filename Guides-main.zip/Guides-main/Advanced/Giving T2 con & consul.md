
# Giving out T2 Constructors / Consuls / Twitchers
<sub></sup>(Author: Zeteo)</sup></sub>



### Proper Times to Hand out T2 Constructors


### Proper Times to Hand out A Consul or Twitcher


