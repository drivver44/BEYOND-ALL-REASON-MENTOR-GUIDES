


Advanced is outlined to go over things as the more basics / intermediate are mastered









