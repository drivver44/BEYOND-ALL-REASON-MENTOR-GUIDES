# Gathering Information
<sub></sup>(Author: Zeteo)</sup></sub>



### Being Aware of What Allies are Doing

### Being Aware of What Enemies are Doing

#### Zooming Camera Out
#### Watching Minimap

### Scouting

#### Scouting by Ground
#### Scouting by Air

### Making Informed Decisions
