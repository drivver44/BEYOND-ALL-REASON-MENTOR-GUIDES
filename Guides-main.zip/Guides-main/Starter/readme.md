




Starter stuff is outlined to cover information for someone whose never played and needs to know the commands/functions of the game







